import { 
    Events, 
    EmbedBuilder, 
    AttachmentBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle 
} from 'discord.js';
import { createCanvas, loadImage } from 'canvas';

export default {
    name: Events.GuildMemberAdd, // Matches the event name
    once: false,
    async execute(member) {
        try {
            const guild = member.guild;

            // =========================
            // 1. CONFIG CHECK
            // =========================
            // Ensure these are in your .env file
            const welcomeChannelId = process.env.WELCOME_CHANNEL_ID;
            if (!welcomeChannelId) return;

            const channel = guild.channels.cache.get(welcomeChannelId);
            if (!channel) return;

            // =========================
            // 2. AUTO ROLE
            // =========================
            if (process.env.AUTO_ROLE_ID) {
                const role = guild.roles.cache.get(process.env.AUTO_ROLE_ID);
                if (role) await member.roles.add(role).catch(err => console.error("AutoRole Error:", err));
            }

            // =========================
            // 3. GENERATE IMAGE (ZeakCloud Theme)
            // =========================
            const width = 900;
            const height = 300;
            const canvas = createCanvas(width, height);
            const ctx = canvas.getContext('2d');

            // -- Background --
            const bgUrl = 'https://img.freepik.com/free-vector/dark-blue-futuristic-digital-background_53876-104046.jpg'; 
            try {
                const background = await loadImage(bgUrl);
                ctx.drawImage(background, 0, 0, width, height);
            } catch (e) {
                ctx.fillStyle = '#0a0a0a'; 
                ctx.fillRect(0, 0, width, height);
            }

            // -- Dark Overlay --
            ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
            ctx.fillRect(0, 0, width, height);

            // -- Glowing Border --
            ctx.strokeStyle = '#33C1FF'; // Cloud Blue
            ctx.lineWidth = 5;
            ctx.strokeRect(0, 0, width, height);

            // -- Avatar --
            const avatarUrl = member.user.displayAvatarURL({ extension: 'png', size: 256 });
            const avatar = await loadImage(avatarUrl);
            const avatarSize = 160;
            const avatarX = 70;
            const avatarY = 70;

            ctx.save();
            ctx.shadowColor = '#33C1FF';
            ctx.shadowBlur = 15;
            ctx.beginPath();
            ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2);
            ctx.closePath();
            ctx.clip();
            ctx.drawImage(avatar, avatarX, avatarY, avatarSize, avatarSize);
            ctx.restore();

            // -- Text --
            ctx.fillStyle = '#ffffff';
            ctx.textAlign = 'left';
            
            ctx.font = '30px Sans';
            ctx.fillText('Welcome to', 270, 110);
            
            ctx.fillStyle = '#33C1FF'; 
            ctx.font = 'bold 65px Sans';
            ctx.fillText('ZeakCloud', 270, 175);
            
            ctx.fillStyle = '#cccccc';
            ctx.font = '25px Sans';
            ctx.fillText(`${member.user.tag} • Member #${guild.memberCount}`, 270, 220);

            const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'zeakcloud-welcome.png' });

            // =========================
            // 4. EMBED DESIGN
            // =========================
            const welcomeEmbed = new EmbedBuilder()
                .setColor('#33C1FF')
                .setTitle('Welcome to ZeakCloud!')
                .setDescription(
                    `Hey ${member}, we're excited to have you here!\n\n` +
                    `🚀 **Get Started:**\n` +
                    `• Open a ticket if you need help\n` +
                    `• Read the rules to keep things clean\n` +
                    `• Say hi in chat and meet the community!`
                )
                .setImage('attachment://zeakcloud-welcome.png')
                .setThumbnail(guild.iconURL({ dynamic: true }))
                .setFooter({ text: 'Powered by ZeakCloud', iconURL: guild.iconURL() })
                .setTimestamp();

            // Buttons
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel('Support Ticket')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('🎫')
                    .setCustomId('ticket_panel_btn') 
                    .setDisabled(true),
                new ButtonBuilder()
                    .setLabel('Visit Website')
                    .setStyle(ButtonStyle.Link)
                    .setURL('https://zeakmc.fun') 
            );

            // =========================
            // 5. SEND MESSAGE
            // =========================
            await channel.send({ 
                content: `👋 Welcome <@${member.id}>!`,
                embeds: [welcomeEmbed], 
                files: [attachment],
                components: [row]
            });

        } catch (err) {
            console.error('[Welcome Error]', err);
        }
    }
};
